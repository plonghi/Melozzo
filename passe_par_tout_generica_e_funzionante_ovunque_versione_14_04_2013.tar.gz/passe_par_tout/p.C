#include <passe_par_tout.h>
int main(int narg, char ** args, char ** env)
 {const char *u="\0", *str = new char[256];
#ifdef LINUX
  int K = 800;
  const char *f[]={"adobe", "courier", "bold", "r", "*", "*", "34", "*", "*", "*", "*", "*", "iso8859", "1"};
#else
  int K = 700;
  const char *f[]={"adobe", "courier", "medium", "r", "*", "*", "30", "*", "*", "*", "p", "*", "*", "*"};
#endif
  double xmin = -1.0, ymin = -1.0, xmax = 1.0, ymax = 1.0, x[2],
   scala = 1.0, sf, r = 0.8, g = 0.6, b = 0.0;
  int L = 80, i, k[2];
  cout << "\n\nBenvenuti nel programma di test dell'installazione di passe_par_tout.\n\n"
       << "si dovrebbe aprire una finestra, al centro dello schermo,\n"
       << "contenente la versione corrente della libreria\n"
       << "in caratteri dorati.\n"
       << "(Se non dovesse apparire istantaneamente\n"
       << "si suggerisce di digitare una qualsiasi lettera mentre il \n"
       << "puntatore del mouse si trova entro la finestra).\n\n"
       << "Dovrebbe anche essere creato, nella directory in cui hai scaricato la cartella\n"
       << "di installazione, un file PostScript, di nome \"passe_par_tout.ps\",\n"
       << "che dovrebbe essere visualizzabile con un programma\n"
       << "adatto ( ad esempio  gv ).\n\n"
       << "Battere <invio> per avviare e seguire successivamente le istruzioni \n"
       << "dettate dal programma.\n\n"<<flush,
  getchar(),
  fclose(stderr),
  sprintf(const_cast<char *>(str), "passe_par_tout versione %s", mversione_passe_par_tout()),
  sf = 2.0, i = 0,
  mrapporto_assi(&i, &sf), sf = 1.8,
  minizio_ps(const_cast<char *>("../passe_par_tout.ps"), &scala, &sf), mfinestra_ps(&xmin, &ymin, &xmax, &ymax),
  mcolore_rgb_ps(&r, &g, &b, &i),
  x[0] = -0.95, x[1] = 0.5*(ymin+ymax),
  mscrivi_ps(const_cast<char *>(str), x, &b),
  mfine_ps();
  if(!getenv("DISPLAY") || !m_startg(const_cast<char *>(u), &K, &L))
   {printf("il DISPLAY risulta inaccessibile;\nlibreria comunque installata:\n\
controllare la presenza del file  ../passe_par_tout.ps\n\n");
    return 0;}
  m_new_color(&r, &g, &b),
  i = 8,
  m_inquire_monitor_size(k, k+1),
  k[0] /= 2, k[0] -= (K/2),
  k[1] /= 2, k[1] -= (L/2),
  m_place_window(k, const_cast<char *>("passe_par_tout (X per tutti)")),
  K = 100 << 24, L = 0,
  m_window(&K, &L),
  m_color(&i),
  m_frame(&xmin, &ymin, &xmax, &ymax), i = 14, L = 35, K = 0,
  m_font(&K, &L, &i, f[0], f[1], f[2], f[3], f[4], f[5], f[6], f[7], f[8], f[9], f[10], f[11], f[12], f[13]),
  x[0] = -0.95, x[1] = 0.5*(ymin+ymax),
  m_text(const_cast<char *>(str), x), m_flush(), i = 0, m_redraw(&i), m_redraw(&i),
  printf("cliccare sulla finestra per uscire\n"), fflush(stdout),
  m_mouse(x), m_endg();}
